# HitVgo 本机助手（Local Agent）

在用户电脑上运行，由网页把自定义 RunningHub / ComfyUI / LLM 任务交给本助手执行，**避免浏览器跨域**。

## 快速开始（Windows）

1. 解压本目录
2. 双击 `start.bat`（首次会自动创建虚拟环境并安装依赖）
3. 看到「已就绪，请回到网页点击检测连接」后，回到 HitVgo 设置页点 **检测连接**

默认地址：`http://127.0.0.1:39281`

## 手动启动

```bash
cd local_agent
python -m venv .venv
.venv\Scripts\pip install -r requirements.txt
.venv\Scripts\python app.py
```

环境变量（可选）：

- `VFLOW_AGENT_HOST`（默认 `127.0.0.1`）
- `VFLOW_AGENT_PORT`（默认 `39281`）

配置文件：`~/.vflow-agent/config.json`（也可由网页「保存」同步）。

## API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/health` | 健康检查 |
| GET/PUT | `/config` | 读写本机配置 |
| POST | `/v1/video/run` | multipart：`meta` + `startImage` + 可选 `endImage`。`meta.useDuckEncrypt` 为真时对非视频（鸭鸭图 PNG）自动解密 |
| POST | `/v1/llm/chat` | OpenAI 兼容转发 |

仅绑定本机回环地址，请勿改为 `0.0.0.0` 除非你清楚风险。
