"""RunningHub / ComfyUI runners for the local agent (server-side, no browser CORS)."""

from __future__ import annotations

import copy
import time
import uuid
from typing import Any, Dict, List, Optional, Tuple

import requests

SEMANTIC_FIELDS = (
    "startImage",
    "endImage",
    "inputVideo",
    "inputAudio",
    "prompt",
    "negative",
    "width",
    "height",
    "length",
    "fps",
    "seedHigh",
    "seedLow",
)


def apply_bindings_to_node_info_list(
    bindings: Dict[str, Any], values: Dict[str, Any]
) -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    seen = set()
    for key in SEMANTIC_FIELDS:
        b = (bindings or {}).get(key)
        if not b or values.get(key) is None or values.get(key) == "":
            continue
        node_id = str(b.get("nodeId", ""))
        field_name = str(b.get("fieldName") or "")
        sig = f"{node_id}:{field_name}"
        if sig in seen:
            continue
        seen.add(sig)
        out.append(
            {
                "nodeId": node_id,
                "fieldName": field_name,
                "fieldValue": str(values[key]),
            }
        )
    return out


def is_comfy_ui_workflow(raw: Any) -> bool:
    if not isinstance(raw, dict):
        return False
    if isinstance(raw.get("nodes"), list) and isinstance(raw.get("links"), list):
        return True
    if "last_node_id" in raw and isinstance(raw.get("nodes"), list):
        return True
    return False


def ui_workflow_to_api_prompt(ui: Dict[str, Any]) -> Dict[str, Any]:
    """Convert ComfyUI canvas export (nodes/links) to API prompt map."""
    links = ui.get("links") or []
    link_map: Dict[Any, Dict[str, Any]] = {}
    for l in links:
        if not isinstance(l, (list, tuple)) or len(l) < 5:
            continue
        link_map[l[0]] = {
            "src": str(l[1]),
            "src_slot": l[2],
            "tgt": str(l[3]),
            "tgt_slot": l[4],
        }
    prompt: Dict[str, Any] = {}
    for node in ui.get("nodes") or []:
        if not isinstance(node, dict) or node.get("id") is None:
            continue
        node_id = str(node["id"])
        inputs: Dict[str, Any] = {}
        wvals = node.get("widgets_values") if isinstance(node.get("widgets_values"), list) else []
        w_idx = 0
        for inp in node.get("inputs") or []:
            if not isinstance(inp, dict):
                continue
            name = inp.get("name") or ((inp.get("widget") or {}).get("name"))
            if not name:
                continue
            if inp.get("link") is not None and inp.get("link") in link_map:
                lk = link_map[inp["link"]]
                inputs[name] = [lk["src"], lk["src_slot"]]
            elif inp.get("widget") is not None or inp.get("link") is None:
                if w_idx < len(wvals):
                    inputs[name] = wvals[w_idx]
                    w_idx += 1
        while w_idx < len(wvals):
            inputs[f"widget_{w_idx}"] = wvals[w_idx]
            w_idx += 1
        prompt[node_id] = {
            "class_type": node.get("type") or "Unknown",
            "inputs": inputs,
            "_meta": {"title": node.get("title") or ""},
        }
    if not prompt:
        raise RuntimeError("UI workflow convert produced empty prompt")
    return prompt


def resolve_comfy_workflow(adapter_mode: Dict[str, Any]) -> Dict[str, Any]:
    workflow = (adapter_mode or {}).get("workflow")
    if isinstance(workflow, dict) and workflow:
        if is_comfy_ui_workflow(workflow):
            return ui_workflow_to_api_prompt(workflow)
        return workflow
    workflow_ui = (adapter_mode or {}).get("workflowUi")
    if isinstance(workflow_ui, dict) and is_comfy_ui_workflow(workflow_ui):
        return ui_workflow_to_api_prompt(workflow_ui)
    raise RuntimeError("Comfy adapter needs bindings + workflow")


def apply_bindings_to_comfy_workflow(
    workflow: Dict[str, Any], bindings: Dict[str, Any], values: Dict[str, Any]
) -> Dict[str, Any]:
    graph = copy.deepcopy(workflow or {})
    for key in SEMANTIC_FIELDS:
        b = (bindings or {}).get(key)
        if not b or values.get(key) is None or values.get(key) == "":
            continue
        node = graph.get(str(b.get("nodeId")))
        if not node:
            continue
        if "inputs" not in node or not isinstance(node["inputs"], dict):
            node["inputs"] = {}
        node["inputs"][str(b.get("fieldName") or "")] = values[key]
    return graph


def _rh_headers(api_key: str) -> Dict[str, str]:
    return {"Authorization": f"Bearer {api_key}"}


def rh_upload_image(
    base_url: str, api_key: str, file_bytes: bytes, filename: str
) -> str:
    url = f"{base_url.rstrip('/')}/task/openapi/upload"
    files = {"file": (filename or "image.png", file_bytes)}
    data = {"apiKey": api_key}
    resp = requests.post(url, headers=_rh_headers(api_key), data=data, files=files, timeout=120)
    json_body = {}
    try:
        json_body = resp.json()
    except Exception:
        pass
    if not resp.ok or (json_body.get("code") is not None and json_body.get("code") != 0):
        raise RuntimeError(
            json_body.get("msg")
            or json_body.get("message")
            or f"RH upload HTTP {resp.status_code}"
        )
    data_obj = json_body.get("data") or json_body
    name = (
        data_obj.get("fileName")
        or data_obj.get("file_name")
        or data_obj.get("filename")
    )
    if not name:
        raise RuntimeError("RH upload: no fileName")
    return str(name)


def rh_create_task(
    base_url: str, api_key: str, workflow_id: str, node_info_list: List[Dict[str, str]]
) -> str:
    url = f"{base_url.rstrip('/')}/task/openapi/create"
    payload = {
        "apiKey": api_key,
        "workflowId": workflow_id,
        "nodeInfoList": node_info_list,
    }
    resp = requests.post(
        url, headers={**_rh_headers(api_key), "Content-Type": "application/json"}, json=payload, timeout=60
    )
    json_body = {}
    try:
        json_body = resp.json()
    except Exception:
        pass
    if not resp.ok or json_body.get("code") != 0:
        raise RuntimeError(
            json_body.get("msg")
            or json_body.get("message")
            or f"RH create HTTP {resp.status_code}"
        )
    task_id = (json_body.get("data") or {}).get("taskId")
    if task_id is None:
        raise RuntimeError("RH create: no taskId")
    return str(task_id)


def rh_poll_outputs(
    base_url: str, api_key: str, task_id: str, timeout_ms: int = 15 * 60 * 1000
) -> str:
    url = f"{base_url.rstrip('/')}/task/openapi/outputs"
    deadline = time.time() + timeout_ms / 1000.0
    while time.time() < deadline:
        resp = requests.post(
            url,
            headers={**_rh_headers(api_key), "Content-Type": "application/json"},
            json={"apiKey": api_key, "taskId": task_id},
            timeout=60,
        )
        json_body = {}
        try:
            json_body = resp.json()
        except Exception:
            pass
        code = json_body.get("code")
        data = json_body.get("data")
        if code == 0 and isinstance(data, list) and data:
            file_url = (
                data[0].get("fileUrl")
                or data[0].get("url")
                or data[0].get("file_url")
                or ((data[0].get("files") or [None])[0])
            )
            if file_url:
                return str(file_url)
        status = ""
        if isinstance(data, dict):
            status = str(data.get("taskStatus") or "")
        status = status or str(json_body.get("msg") or "")
        if status and ("fail" in status.lower() or "error" in status.lower()):
            raise RuntimeError(json_body.get("msg") or status or "RH task failed")
        time.sleep(3)
    raise RuntimeError("RH poll timeout")


def download_bytes(url: str) -> bytes:
    resp = requests.get(url, timeout=300)
    if not resp.ok:
        raise RuntimeError(f"Download HTTP {resp.status_code}")
    return resp.content


def run_rh_job(
    *,
    base_url: str,
    api_key: str,
    adapter_mode: Dict[str, Any],
    values: Dict[str, Any],
    start_image: Optional[Tuple[bytes, str]],
    end_image: Optional[Tuple[bytes, str]],
    input_video: Optional[Tuple[bytes, str]] = None,
    input_audio: Optional[Tuple[bytes, str]] = None,
) -> Tuple[bytes, str]:
    bindings = (adapter_mode or {}).get("bindings") or {}
    workflow_id = str((adapter_mode or {}).get("workflowId") or "").strip()
    if not bindings:
        raise RuntimeError("Missing adapter bindings")
    if not workflow_id:
        raise RuntimeError("Missing workflowId")
    if not api_key:
        raise RuntimeError("Missing RunningHub API Key")

    vals = dict(values or {})
    if start_image:
        vals["startImage"] = rh_upload_image(
            base_url, api_key, start_image[0], start_image[1] or "start.png"
        )
    if end_image:
        vals["endImage"] = rh_upload_image(
            base_url, api_key, end_image[0], end_image[1] or "end.png"
        )
    if input_video:
        vals["inputVideo"] = rh_upload_image(
            base_url, api_key, input_video[0], input_video[1] or "input.mp4"
        )
    if input_audio:
        vals["inputAudio"] = rh_upload_image(
            base_url, api_key, input_audio[0], input_audio[1] or "input.mp3"
        )
    if not vals.get("startImage") and not vals.get("inputVideo"):
        raise RuntimeError("Missing start image or input video")
    if bindings.get("inputAudio") and not vals.get("inputAudio"):
        raise RuntimeError("Missing input audio")

    node_info_list = apply_bindings_to_node_info_list(bindings, vals)
    task_id = rh_create_task(base_url, api_key, workflow_id, node_info_list)
    file_url = rh_poll_outputs(base_url, api_key, task_id)
    return download_bytes(file_url), task_id


def _comfy_headers(auth_header: str) -> Dict[str, str]:
    h: Dict[str, str] = {}
    if auth_header:
        h["Authorization"] = auth_header
    return h


def comfy_upload_image(
    base_url: str, auth_header: str, file_bytes: bytes, filename: str
) -> str:
    url = f"{base_url.rstrip('/')}/upload/image"
    files = {"image": (filename or "image.png", file_bytes)}
    data = {"overwrite": "true"}
    resp = requests.post(
        url, headers=_comfy_headers(auth_header), data=data, files=files, timeout=120
    )
    json_body = {}
    try:
        json_body = resp.json()
    except Exception:
        pass
    if not resp.ok:
        raise RuntimeError(
            json_body.get("error") or f"Comfy upload HTTP {resp.status_code}"
        )
    name = json_body.get("name") or ((json_body.get("files") or [None])[0]) or filename
    return str(name)


def comfy_queue_prompt(
    base_url: str, auth_header: str, workflow: Dict[str, Any]
) -> str:
    url = f"{base_url.rstrip('/')}/prompt"
    client_id = f"cli_{uuid.uuid4().hex[:12]}"
    resp = requests.post(
        url,
        headers={**_comfy_headers(auth_header), "Content-Type": "application/json"},
        json={"prompt": workflow, "client_id": client_id},
        timeout=60,
    )
    json_body = {}
    try:
        json_body = resp.json()
    except Exception:
        pass
    if not resp.ok or json_body.get("error"):
        err = json_body.get("error")
        if isinstance(err, dict):
            msg = err.get("message") or str(err)
        else:
            msg = str(err or json_body) or f"Comfy prompt HTTP {resp.status_code}"
        raise RuntimeError(msg)
    prompt_id = json_body.get("prompt_id") or json_body.get("promptId")
    if not prompt_id:
        raise RuntimeError("Comfy: no prompt_id")
    return str(prompt_id)


def comfy_wait_history(
    base_url: str, auth_header: str, prompt_id: str, timeout_ms: int = 15 * 60 * 1000
) -> Dict[str, Any]:
    deadline = time.time() + timeout_ms / 1000.0
    hist_url = f"{base_url.rstrip('/')}/history/{prompt_id}"
    while time.time() < deadline:
        resp = requests.get(hist_url, headers=_comfy_headers(auth_header), timeout=60)
        if resp.ok:
            json_body = resp.json()
            entry = json_body.get(prompt_id)
            if not entry and isinstance(json_body, dict) and json_body:
                entry = next(iter(json_body.values()))
            if entry and entry.get("outputs"):
                return entry
        time.sleep(2)
    raise RuntimeError("Comfy poll timeout")


def find_comfy_video_url(base_url: str, history_entry: Dict[str, Any]) -> Optional[str]:
    outputs = (history_entry or {}).get("outputs") or {}
    for _node_id, o in outputs.items():
        videos = o.get("gifs") or o.get("videos") or o.get("images") or []
        for v in videos:
            if not v or not v.get("filename"):
                continue
            sub = ""
            if v.get("subfolder"):
                from urllib.parse import quote

                sub = f"&subfolder={quote(str(v['subfolder']))}"
            t = v.get("type") or "output"
            from urllib.parse import quote

            return (
                f"{base_url.rstrip('/')}/view?filename={quote(str(v['filename']))}"
                f"&type={quote(str(t))}{sub}"
            )
    return None


def run_comfy_job(
    *,
    base_url: str,
    auth_header: str,
    adapter_mode: Dict[str, Any],
    values: Dict[str, Any],
    start_image: Optional[Tuple[bytes, str]],
    end_image: Optional[Tuple[bytes, str]],
    input_video: Optional[Tuple[bytes, str]] = None,
    input_audio: Optional[Tuple[bytes, str]] = None,
) -> Tuple[bytes, str]:
    bindings = (adapter_mode or {}).get("bindings") or {}
    workflow = resolve_comfy_workflow(adapter_mode or {})
    if not bindings:
        raise RuntimeError("Comfy adapter needs bindings + workflow")

    vals = dict(values or {})
    if start_image:
        vals["startImage"] = comfy_upload_image(
            base_url, auth_header, start_image[0], start_image[1] or "start.png"
        )
    if end_image:
        vals["endImage"] = comfy_upload_image(
            base_url, auth_header, end_image[0], end_image[1] or "end.png"
        )
    if input_video:
        vals["inputVideo"] = comfy_upload_image(
            base_url, auth_header, input_video[0], input_video[1] or "input.mp4"
        )
    if input_audio:
        vals["inputAudio"] = comfy_upload_image(
            base_url, auth_header, input_audio[0], input_audio[1] or "input.mp3"
        )
    if not vals.get("startImage") and not vals.get("inputVideo"):
        raise RuntimeError("Missing start image or input video")
    if bindings.get("inputAudio") and not vals.get("inputAudio"):
        raise RuntimeError("Missing input audio")

    graph = apply_bindings_to_comfy_workflow(workflow, bindings, vals)
    prompt_id = comfy_queue_prompt(base_url, auth_header, graph)
    hist = comfy_wait_history(base_url, auth_header, prompt_id)
    file_url = find_comfy_video_url(base_url, hist)
    if not file_url:
        raise RuntimeError("Comfy: no video output")
    return download_bytes(file_url), prompt_id
