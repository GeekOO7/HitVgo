#!/usr/bin/env python3
"""
Vflow / HitVgo local agent — runs on 127.0.0.1 only.

The website talks to this process instead of calling RunningHub / Comfy / LLM
from the browser (avoids CORS). Credentials stay on the user's machine.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


def _fix_stdio() -> None:
    """Avoid UnicodeEncodeError on Windows GBK consoles when printing Chinese."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


_fix_stdio()

from flask import Flask, Response, jsonify, request

# Allow running as script from any cwd
_ROOT = Path(__file__).resolve().parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

from runners import run_comfy_job, run_rh_job  # noqa: E402
import duck_decode  # noqa: E402

VERSION = "0.1.2"
DEFAULT_HOST = "127.0.0.1"
DEFAULT_PORT = 39281
CONFIG_DIR = Path.home() / ".vflow-agent"
CONFIG_PATH = CONFIG_DIR / "config.json"

ALLOWED_ORIGINS = {
    "https://hitvgo.geek007.com",
    "http://hitvgo.geek007.com",
    "https://cte.7766.org",
    "http://cte.7766.org",
    "http://127.0.0.1",
    "http://localhost",
}

_EXT_MIME = {
    "mp4": "video/mp4",
    "webm": "video/webm",
    "mov": "video/quicktime",
    "png": "image/png",
    "jpg": "image/jpeg",
    "jpeg": "image/jpeg",
    "webp": "image/webp",
    "bin": "application/octet-stream",
}


def _looks_like_video_bytes(data: bytes) -> bool:
    if not data or len(data) < 12:
        return False
    if data[4:8] == b"ftyp":
        return True
    if data[:4] == b"\x1a\x45\xdf\xa3":
        return True
    return False


def _is_png_bytes(data: bytes) -> bool:
    return bool(data) and data[:8] == b"\x89PNG\r\n\x1a\n"


def _replace_filename_ext(filename: str, ext: str) -> str:
    name = filename or f"local.{ext}"
    stem = Path(name).stem or "local"
    clean_ext = (ext or "mp4").lower().lstrip(".")
    return f"{stem}.{clean_ext}"


def maybe_decrypt_output(
    raw: bytes, use_duck: bool, password: str, filename: str
) -> Tuple[bytes, str, str, bool]:
    """Return (bytes, filename, mimetype, decrypted)."""
    if not use_duck:
        return raw, filename, "video/mp4", False
    if _looks_like_video_bytes(raw):
        return raw, filename, "video/mp4", False
    if not _is_png_bytes(raw):
        raise RuntimeError(
            "已开启鸭鸭图解密，但成片既不是视频也不是 PNG 鸭鸭图"
        )
    try:
        media_bytes, ext = duck_decode.decode_duck_bytes(raw, password or "")
    except ValueError as exc:
        raise RuntimeError(str(exc) or "鸭鸭图解密失败") from exc
    ext = (ext or "mp4").lower().lstrip(".")
    if ext not in _EXT_MIME:
        ext = "mp4"
    out_name = _replace_filename_ext(filename, ext)
    mime = _EXT_MIME.get(ext, "video/mp4")
    return media_bytes, out_name, mime, True

app = Flask(__name__)


def default_config() -> Dict[str, Any]:
    return {
        "rh": {
            "baseUrl": "https://www.runninghub.ai",
            "apiKey": "",
            "workflowIdI2v": "",
            "workflowIdFlf": "",
            "adapter": None,
        },
        "comfy": {
            "baseUrl": "http://127.0.0.1:8188",
            "authHeader": "",
            "adapter": None,
        },
        "llm": {
            "baseUrl": "https://openrouter.ai/api/v1",
            "apiKey": "",
            "model": "",
        },
    }


def load_config() -> Dict[str, Any]:
    cfg = default_config()
    if CONFIG_PATH.is_file():
        try:
            raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for key in ("rh", "comfy", "llm"):
                    if isinstance(raw.get(key), dict):
                        cfg[key].update(raw[key])
        except Exception:
            pass
    return cfg


def save_config(cfg: Dict[str, Any]) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(
        json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    try:
        os.chmod(CONFIG_PATH, 0o600)
    except Exception:
        pass


def cors_origin() -> str:
    origin = request.headers.get("Origin") or ""
    if not origin:
        return "*"
    if origin in ALLOWED_ORIGINS:
        return origin
    # Local agent only binds 127.0.0.1 — allow any site origin for ease of use
    # (including custom deploy domains).
    if origin.startswith("http://") or origin.startswith("https://"):
        return origin
    return "null"


def apply_cors(resp: Response) -> Response:
    origin = cors_origin()
    resp.headers["Access-Control-Allow-Origin"] = origin
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, OPTIONS"
    resp.headers["Access-Control-Allow-Headers"] = (
        "Content-Type, Authorization, X-Requested-With"
    )
    resp.headers["Access-Control-Allow-Private-Network"] = "true"
    resp.headers["Access-Control-Expose-Headers"] = "X-Task-Id, X-Agent-Version, Content-Type"
    if origin != "*":
        resp.headers["Vary"] = "Origin"
    return resp


@app.after_request
def _after(resp: Response) -> Response:
    return apply_cors(resp)


@app.route("/", methods=["GET", "OPTIONS"])
@app.route("/health", methods=["GET", "OPTIONS"])
def health():
    if request.method == "OPTIONS":
        return ("", 204)
    cfg = load_config()
    return jsonify(
        {
            "ok": True,
            "version": VERSION,
            "name": "vflow-local-agent",
            "channels": {
                "rh": bool((cfg.get("rh") or {}).get("apiKey")),
                "comfy": bool((cfg.get("comfy") or {}).get("baseUrl")),
                "llm": bool((cfg.get("llm") or {}).get("apiKey")),
            },
            "configPath": str(CONFIG_PATH),
        }
    )


@app.route("/config", methods=["GET", "PUT", "OPTIONS"])
def config_route():
    if request.method == "OPTIONS":
        return ("", 204)
    if request.method == "GET":
        return jsonify(load_config())
    body = request.get_json(silent=True) or {}
    if not isinstance(body, dict):
        return jsonify({"ok": False, "error": "Invalid JSON"}), 400
    cfg = load_config()
    for key in ("rh", "comfy", "llm"):
        if isinstance(body.get(key), dict):
            cfg[key].update(body[key])
    save_config(cfg)
    return jsonify({"ok": True, "config": cfg})


def _file_tuple(name: str) -> Optional[Tuple[bytes, str]]:
    f = request.files.get(name)
    if not f:
        return None
    data = f.read()
    if not data:
        return None
    return data, f.filename or f"{name}.png"


@app.route("/v1/video/run", methods=["POST", "OPTIONS"])
def video_run():
    if request.method == "OPTIONS":
        return ("", 204)
    try:
        meta_raw = request.form.get("meta") or "{}"
        meta = json.loads(meta_raw)
        if not isinstance(meta, dict):
            raise RuntimeError("meta must be a JSON object")
        channel = str(meta.get("channel") or "")
        adapter_mode = meta.get("adapterMode") or {}
        values = meta.get("values") or {}
        if not isinstance(adapter_mode, dict) or not isinstance(values, dict):
            raise RuntimeError("adapterMode/values must be objects")

        cfg = load_config()
        # Prefer request-embedded credentials if provided (synced from settings)
        rh_cfg = {**(cfg.get("rh") or {}), **(meta.get("rh") or {})}
        comfy_cfg = {**(cfg.get("comfy") or {}), **(meta.get("comfy") or {})}

        start_image = _file_tuple("startImage")
        end_image = _file_tuple("endImage")
        input_video = _file_tuple("inputVideo")
        input_audio = _file_tuple("inputAudio")

        if channel == "custom_rh":
            video_bytes, task_id = run_rh_job(
                base_url=str(rh_cfg.get("baseUrl") or "https://www.runninghub.ai"),
                api_key=str(rh_cfg.get("apiKey") or ""),
                adapter_mode=adapter_mode,
                values=values,
                start_image=start_image,
                end_image=end_image,
                input_video=input_video,
                input_audio=input_audio,
            )
        elif channel == "comfyui":
            video_bytes, task_id = run_comfy_job(
                base_url=str(comfy_cfg.get("baseUrl") or "http://127.0.0.1:8188"),
                auth_header=str(comfy_cfg.get("authHeader") or ""),
                adapter_mode=adapter_mode,
                values=values,
                start_image=start_image,
                end_image=end_image,
                input_video=input_video,
                input_audio=input_audio,
            )
        else:
            raise RuntimeError(f"Unsupported channel: {channel}")

        use_duck = bool(meta.get("useDuckEncrypt"))
        password = str(meta.get("password") or "")
        filename = str(meta.get("filename") or f"local_{task_id}.mp4")
        out_bytes, filename, mime, decrypted = maybe_decrypt_output(
            video_bytes, use_duck, password, filename
        )
        resp = Response(out_bytes, mimetype=mime)
        resp.headers["Content-Disposition"] = f'attachment; filename="{filename}"'
        resp.headers["X-Task-Id"] = str(task_id)
        resp.headers["X-Agent-Version"] = VERSION
        resp.headers["X-Decrypted"] = "1" if decrypted else "0"
        return resp
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route("/v1/llm/chat", methods=["POST", "OPTIONS"])
def llm_chat():
    if request.method == "OPTIONS":
        return ("", 204)
    try:
        import requests as req_lib

        body = request.get_json(silent=True) or {}
        cfg = load_config()
        llm = {**(cfg.get("llm") or {}), **(body.get("llm") or {})}
        api_key = str(llm.get("apiKey") or "")
        base_url = str(llm.get("baseUrl") or "").rstrip("/")
        model = str(llm.get("model") or body.get("model") or "")
        if not api_key:
            raise RuntimeError("Missing LLM API Key — configure in settings and sync")
        if not base_url:
            raise RuntimeError("Missing LLM baseUrl")
        if not model:
            raise RuntimeError("Missing LLM model")

        messages = body.get("messages")
        if not messages:
            system = body.get("system") or ""
            user_msg = body.get("userMsg") or body.get("user") or ""
            messages = [
                {"role": "system", "content": system},
                {"role": "user", "content": user_msg},
            ]

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
        if "openrouter.ai" in base_url:
            headers["HTTP-Referer"] = "https://hitvgo.geek007.com"
            headers["X-Title"] = "HitVgo"

        payload = {
            "model": model,
            "messages": messages,
            "temperature": body.get("temperature", 0.7),
        }
        resp = req_lib.post(
            f"{base_url}/chat/completions",
            headers=headers,
            json=payload,
            timeout=180,
        )
        result = {}
        try:
            result = resp.json()
        except Exception:
            pass
        if not resp.ok:
            msg = (
                (result.get("error") or {}).get("message")
                if isinstance(result.get("error"), dict)
                else result.get("error") or result.get("message") or f"HTTP {resp.status_code}"
            )
            raise RuntimeError(str(msg))
        content = (
            ((result.get("choices") or [{}])[0].get("message") or {}).get("content")
        )
        if not content:
            raise RuntimeError("LLM returned empty choices")
        return jsonify({"ok": True, "content": content, "raw": result})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


def main() -> None:
    host = os.environ.get("VFLOW_AGENT_HOST", DEFAULT_HOST)
    port = int(os.environ.get("VFLOW_AGENT_PORT", str(DEFAULT_PORT)))
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    if not CONFIG_PATH.is_file():
        save_config(default_config())

    banner = (
        "\n"
        "========================================\n"
        f"  HitVgo 本机助手 v{VERSION}\n"
        f"  监听: http://{host}:{port}\n"
        "  已就绪，请回到网页点击「检测连接」\n"
        f"  配置: {CONFIG_PATH}\n"
        "  保持本窗口开启；关闭即停止助手\n"
        "========================================\n"
    )
    print(banner, flush=True)
    # threaded=True so long video jobs don't block health checks
    app.run(host=host, port=port, threaded=True, use_reloader=False)


if __name__ == "__main__":
    main()
